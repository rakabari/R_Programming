#'
#' Export amino acids sequence to fasta file format
#'
AA2Fasta <- function(seql=Code_list, File_AA="File_AA") {
  names(seql) <- paste(">", names(seql), sep="")
  export <- data.frame(IDs=names(seql), seq=unlist(seql))
  export <- as.vector(unlist(t(export)))
  write.table(export, file=paste(File_AA, ".txt", sep=""), quote=F, row.names=F, col.names=F)
}
cat("\n# Export amino acid sequences in fasta format:\n\t AA2Fasta(seql=Code_list, File_AA=\"File_AA\")\n")
