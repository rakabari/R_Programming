#'
#' Function  to Import Sequence
#'
Import_Sequence <- function(fileloc) {
  FASTA_File <- readLines(fileloc)
  y <- regexpr("^[^>]", FASTA_File, perl=T) # detects fields that do not beign with a '>' sign
  y <- as.vector(y);  y[y==-1] <- 0
  index <- which(y==0)
  distance <- data.frame(start=index[1:(length(index)-1)], end=index[2:length(index)])
  distance <- rbind(distance, c(distance[length(distance[,1]),2], length(y)+1)) # to get data for entry at the end
  distance <- data.frame(distance, dist=distance[,2]-distance[,1])
  seq_no <- 1:length(y[y==0])
  index <- rep(seq_no, as.vector(distance[,3]))
  FASTA_File <- data.frame(index, y, FASTA_File)
  FASTA_File[FASTA_File[,2]==0,1] <- 0
  seq <- tapply(as.vector(FASTA_File[,3]), factor(FASTA_File[,1]), paste, collapse="", simplify=F)
  seq <- as.vector(seq[2:length(seq)])
  Desc <- as.vector(FASTA_File[c(grep("^>", as.character(FASTA_File[,3]), perl = TRUE)),3])
  ID <- gsub("^>| .*", "", as.character(Desc), perl=T)
  Desc <- gsub("^.*? ", "", as.character(Desc), perl=T)
  FASTA_File <- data.frame(ID, Desc, Length=nchar(seq), seq)
  FASTA_File
}
cat("\n# Import Open Reading Frames (ORFs): \n\t myseq <- Import_Sequence (\"https://raw.githubusercontent.com/rakabari/R_Programming/master/FASTASeq.txt\")\n")
cat("\n# Import codon table:\n\t CT <- read.table(file=\"https://github.com/rakabari/R_Programming/blob/master/CT.txt\", header=T, sep=\"\\t\")\n")

Import_Sequence(fileloc = "C:/Users/Ratie/Desktop/R Project/DNA.fasta")
