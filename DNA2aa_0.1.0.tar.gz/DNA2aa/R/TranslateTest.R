#'
#' TranslateTest function to translate a single DNA sequence
#'
TranslateTest <- function(string1="", ORF, CodeY=CodeY) { # "CodeY" can have the values 3 or 4; the argument "ORF" can have one integer between 1 and 6.
  string1 <- gsub("(...)", "\\1_", string1) # inserts '_' between characters in a string
  string1 <- unlist(strsplit(string1 , "_")) # produces triplet sequence
  string1 <- string1[grep("^...$", string1)]
  string1 <- data.frame(Order=1:length(string1), Seq=string1)
  if(ORF==1|ORF==2|ORF==3) {
    string1 <- merge(string1, CT, by.x="Seq", by.y="Codon", all.x=T) # Combines codon table with DNA sequence.
    string1[,CodeY] <- as.character(string1[,CodeY])
    string1[,CodeY][is.na(string1[,CodeY])] <- "X" # is used to assign 'X's to unusual characters (e.g. N's) in triplet sequence
    string1 <- paste(as.vector(string1[order(string1[,2]), CodeY]), collapse="")
  }
  if(ORF==4|ORF==5|ORF==6) {
    string1 <- merge(string1, CT, by.x="Seq", by.y="AntiCodon", all.x=T) # Combines codon table with DNA sequence.
    string1 <- string1[,c(1,2,4,5,6,3)] # receives same column order as for ORF 1-3
    string1[,CodeY] <- as.character(string1[,CodeY])
    string1[,CodeY][is.na(string1[,CodeY])] <- "X" # is used to assign 'X's to unusual characters (e.g. N's) in triplet sequence
    string1 <- paste(as.vector(string1[rev(order(string1[,2])), CodeY]), collapse="") # produces reverse amino acid sequence
  }
  string1
}
