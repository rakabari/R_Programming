#'
#' DNATranslate function to convert DNA into 6 ORFs and translate them with the TranslateTest function
#'
DNATranslate <- function(seq1=seq1, ORF=c(1,2,3,4,5,6), CodeY="single") { # ORF selects any combination of the 6 ORFs
  if(CodeY=="single") { CodeY <- 3 }
  if(CodeY=="triple") { CodeY <- 4 }
  seq1 <- gsub("([A-Z])", "\\U\\1", as.character(seq1), perl=T, ignore.case=T) # Looks for case inconsistencies
  ORF1 <- seq1
  ORF2 <- gsub("^.", "", seq1)
  ORF3 <- gsub("^..", "", seq1)
  leq <- list(ORF1=ORF1, ORF2=ORF2, ORF3=ORF3, ORF4=ORF1, ORF5=ORF2, ORF6=ORF3)
  # The next line performs translate() on the ORFs that are specified by the 'ORF' argument
  leq <- lapply(names(leq)[ORF], function(x) TranslateTest(mystr=leq[x], ORF=which(names(leq) %in% x), CodeY=CodeY))
  names(leq) <- paste(rep("ORF", length(ORF)), ORF, sep="")
  leq
}
cat("\n# Translate DNAs in all 6 ORFs:\n\t Code_list <- apply(data.ORF(seq1[1:10,4]), 1, function(x) DNATranslate(seq1=x, ORF=c(1,2,3,4,5,6), CodeY=\"single\"))\n")
cat("\n# Assign names to amino acid sequences:\n\t names(Code_list) <- seq1[1:10,1]\n\t Code_list <- as.list(unlist(Code_list))\n")
